#include "mainwindow.h"
#include "mapwidget.h"
#include <QApplication>
#include<QFont>
#include <QDebug>
#include <QPixmap>
#include <QSplashScreen>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    /*
    QPixmap pixmap("E:/campus_tour/campus_tour/Bupt.jpeg");         //创建启动界面图片
    QSplashScreen splash(pixmap);   //启动界面
    splash.show();                  //显示图片
    */

    a.processEvents();              //接收事件

    QFont font("ARPL KaitiM GB", 18);//设置字体
    font.setBold(true);
    a.setFont(font);

    qDebug()<<"启动中";

    MainWindow w;
    w.show();

    QDir dir;
       QString pathname;
       //修改相对路径为exe目录路径
       QDir::setCurrent(QCoreApplication::applicationDirPath());
       pathname = dir.currentPath();
       qDebug()<<pathname;


    //结束动画
    //splash.finish (&w);

    return a.exec();
}
